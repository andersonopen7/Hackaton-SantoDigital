                MANUAL SIMPLES DE FUNCIONAMENTO LOCAL
---------------------------------------------------------------------

Para executar o código Terraform que forneci, siga estes passos:

Instale o Terraform:
Baixe e instale o Terraform a partir do site oficial.

Crie um diretório para o seu projeto:
Crie uma nova pasta e navegue até ela:
Entre na pasta criada

Crie um arquivo de configuração Terraform:
Crie um arquivo chamado main.tf e cole o código fornecido nele.
Inicialize o Terraform:
No terminal, dentro do diretório do projeto, execute:
terraform init

Revise e aplique o plano Terraform:
Revise o plano de execução:
terraform plan

Aplique o plano para criar os recursos:
terraform apply

Confirme a aplicação digitando yes quando solicitado.
Verifique a implantação:

----------------------------------------------------------------------

